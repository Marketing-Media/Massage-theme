<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsstock}prestashop>statsstock_96ca47f429c269b85e31be9fb17df6d4'] = 'Available quantities';
$_MODULE['<{statsstock}prestashop>statsstock_7782fb19c81ec8a47e39f9c073b7da59'] = 'Adds a tab showing the quantity of available products for sale to the Stats dashboard.';
$_MODULE['<{statsstock}prestashop>statsstock_c49b42f642c62f20a3640f20ca132840'] = 'Evaluation of available quantities for sale';
$_MODULE['<{statsstock}prestashop>statsstock_3adbdb3ac060038aa0e6e6c138ef9873'] = 'Category';
$_MODULE['<{statsstock}prestashop>statsstock_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'All';
$_MODULE['<{statsstock}prestashop>statsstock_1b2379801de373b6b563c347014fb34b'] = 'Your catalog is empty.';
$_MODULE['<{statsstock}prestashop>statsstock_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{statsstock}prestashop>statsstock_12d3c7a4296542c62474856ec452c045'] = 'Ref.';
$_MODULE['<{statsstock}prestashop>statsstock_7d74f3b92b19da5e606d737d339a9679'] = 'Item';
$_MODULE['<{statsstock}prestashop>statsstock_7bd5825a187064017975513b95d7f7de'] = 'Available quantity for sale';
$_MODULE['<{statsstock}prestashop>statsstock_88940d60e75cf4ff38ce27db4efc83b2'] = 'Price*';
$_MODULE['<{statsstock}prestashop>statsstock_689202409e48743b914713f96d93947c'] = 'Value';
$_MODULE['<{statsstock}prestashop>statsstock_347cbf03d737b02a70a96ff204c22fbc'] = 'Total quantities';
$_MODULE['<{statsstock}prestashop>statsstock_844c29394eea07066bb2efefc35784ec'] = 'Average price';
$_MODULE['<{statsstock}prestashop>statsstock_62668f75fc6977f3d09df632d1585d07'] = 'Total value';
$_MODULE['<{statsstock}prestashop>statsstock_a9873f90f06f9e2cfa3d048298ecca8c'] = 'This section corresponds to the default wholesale price according to the default supplier for the product. An average price is used when the product has attributes.';


return $_MODULE;
