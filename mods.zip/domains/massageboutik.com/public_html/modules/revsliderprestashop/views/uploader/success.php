<?php
/**
* 2016 Revolution Slider
*
*  @author    SmatDataSoft <support@smartdatasoft.com>
*  @copyright 2016 SmatDataSoft
*  @license   private
*  @version   5.1.3
*  International Registered Trademark & Property of SmatDataSoft
*/

?>

<html>
  <head>
    <!--JUPLOAD_JSCRIPT-->
    <title>JUpload RESPONSIVE filemanager</title>
    <style>
	body{padding:0px; margin:0px;}
    </style>
    <meta http-equiv="refresh" content="3;url=index.php?path=<?php htmlentities(Tools::getValue('path')); ?>">
  </head>
  <body>
    <center><br/><br/>
    <img src="../img/success.jpg" alt="success">
	</center>
  </body>
</html>