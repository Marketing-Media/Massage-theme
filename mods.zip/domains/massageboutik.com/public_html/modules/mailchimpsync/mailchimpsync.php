<?php
/**
 * 2007-2015 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2015 PrestaShop SA
 *  @license   http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

if (!class_exists('Mailchimp')) {
    include_once _PS_MODULE_DIR_ . 'mailchimpsync/MailChimpClient.php';
}

class MailchimpSync extends Module
{
    public function __construct()
    {
        $this->name             = 'mailchimpsync';
        $this->version          = '3.0.4';
        $this->author           = 'Sébastien Jousse';
        $this->tab              = 'advertising_marketing';
        $this->module_key       = '56bf075ed4d7cbc0ffe5cecdf05bf480';
        $this->ps_versions_compliancy    = array('min' => '1.5', 'max' => '1.6');
        $this->need_instance    = 0;
        $this->bootstrap        = true;

        parent::__construct();

        $this->displayName = $this->l('Mailchimp Sync');
        $this->description = $this->l('Synchronize automatically your list of subscribers in Prestashop with your Mailchimp account, and the reverse too.');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall this module ? All your settings will be lost.');

        if (Configuration::get('MAILCHIMP_LIST_ID') == 0) {
            $this->warning = $this->l('You have not yet set your Mailchimp default list.');
        }
        if (Configuration::get('MAILCHIMP_API_KEY') == '') {
            $this->warning = $this->l('You have not yet set your Mailchimp API key.');
        }
    }

    public function install()
    {
        if (!parent::install()
            || !Configuration::updateValue('MAILCHIMP_WEBHOOK_TOKEN', Tools::strtoupper(Tools::passwdGen(16)))
            || !Configuration::updateValue('MAILCHIMP_API_KEY', '')

            || !Configuration::updateValue('MAILCHIMP_LIST_ID', 0)

            || !Configuration::updateValue('MAILCHIMP_DOUBLE_OPTIN', false)
            || !Configuration::updateValue('MAILCHIMP_DELETE_MEMBER', false)

            || !$this->registerHook('actionObjectCustomerAddAfter')
            || !$this->registerHook('actionObjectCustomerUpdateAfter')
            || !$this->registerHook('displayHeader')
        ) {
            return false;
        }

        return true;
    }

    public function uninstall()
    {
        if (!Configuration::deleteByName('MAILCHIMP_WEBHOOK_TOKEN')
            || !Configuration::deleteByName('MAILCHIMP_API_KEY')

            || !Configuration::deleteByName('MAILCHIMP_LIST_ID')

            || !Configuration::deleteByName('MAILCHIMP_DOUBLE_OPTIN')
            || !Configuration::deleteByName('MAILCHIMP_DELETE_MEMBER')

            || !$this->deleteWebhook()

            || !$this->unregisterHook('displayHeader')
            || !$this->unregisterHook('actionObjectCustomerUpdateAfter')
            || !$this->unregisterHook('actionObjectCustomerAddAfter')

            || !parent::uninstall()
        ) {
            return false;
        }
        return true;
    }

    private function addWebhook()
    {
        $list_id = Configuration::get('MAILCHIMP_LIST_ID');
        if ($this->isConfigured() && $list_id !== '0') {
            $token = Configuration::get('MAILCHIMP_WEBHOOK_TOKEN');
            $webhook_url = Context::getContext()->link->getModuleLink($this->name, 'webhook', array('token' => $token));
            $mailchimp = $this->getClient();
            try {
                $mailchimp->webhookAdd($list_id, $webhook_url, array('subscribe' => true, 'unsubscribe' => true));
            } catch (Exception $exception) {
                return false;
            }
            return true;
        }
        return false;
    }

    private function deleteWebhook()
    {
        $list_id = Configuration::get('MAILCHIMP_LIST_ID');
        if ($this->isConfigured() && $list_id !== '0') {
            $token = Configuration::get('MAILCHIMP_WEBHOOK_TOKEN');
            $webhook_url = Context::getContext()->link->getModuleLink($this->name, 'webhook', array('token' => $token));
            $mailchimp = $this->getClient();
            try {
                $mailchimp->webhookDel($list_id, $webhook_url);
            } catch (Exception $exception) {
                return false;
            }
            return true;
        }
        return true;
    }

    private function testAPI($api_key)
    {
        try {
            $mailchimp = $this->getClient($api_key);
            $response = $mailchimp->ping();
            return $response;
        } catch (Exception $exception) {
            return false;
        }
    }

    private function isConfigured()
    {
        return Configuration::get('MAILCHIMP_API_KEY') != null;
    }

    public function getContent()
    {
        $output = null;

        // API key
        if (Tools::isSubmit('submitKey')) {
            $api_key = Tools::getValue('MAILCHIMP_API_KEY');
            if (!$api_key
                || empty($api_key)
                || !$this->testAPI($api_key)
            ) {
                $output .= $this->displayError($this->l('Invalid API key'));
            } else {
                Configuration::updateValue('MAILCHIMP_API_KEY', $api_key);
                $output .= $this->displayConfirmation($this->l('Settings updated'));
            }
        }

        // List
        if (Tools::isSubmit('submitList')) {
            $list_id = Tools::getValue('MAILCHIMP_LIST_ID', '0');
            if (empty($list_id) || $list_id === '0') {
                $output .= $this->displayError($this->l('Invalid list'));
            } else {
                // delete existing webhook
                if (Configuration::get('MAILCHIMP_LIST_ID')) {
                    $this->deleteWebhook();
                }
                Configuration::updateValue('MAILCHIMP_LIST_ID', $list_id);
                $this->addWebhook();
                $output .= $this->displayConfirmation($this->l('Settings updated'));
            }
        }

        // Settings
        if (Tools::isSubmit('submitSettings')) {
            $double_optin = Tools::getValue('MAILCHIMP_DOUBLE_OPTIN');
            $delete_member = Tools::getValue('MAILCHIMP_DELETE_MEMBER');
            if ($double_optin === false || $delete_member === false) {
                $output .= $this->displayError($this->l('Invalid settings'));
            } else {
                Configuration::updateValue('MAILCHIMP_DOUBLE_OPTIN', $double_optin);
                Configuration::updateValue('MAILCHIMP_DELETE_MEMBER', $delete_member);
                $output .= $this->displayConfirmation($this->l('Settings updated'));
            }
        }

        return $output.$this->displayForm();
    }

    private function getClient($api_key = '')
    {
        if ($api_key == '') {
            if (!$this->isConfigured()) {
                return null;
            }
            $api_key = Configuration::get('MAILCHIMP_API_KEY');
        }

        $mailchimp    = new MailChimpClient($api_key);
        return $mailchimp;
    }

    private function getLists()
    {
        if (!$this->isConfigured()) {
            return array();
        }

        $mailchimp = $this->getClient();

        try {
            $response = $mailchimp->getLists();
            $lists = $response['lists'];
            return $lists;
        } catch (Exception $exception) {
            return array();
        }
    }

    public function displayForm()
    {
        // Get default language
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
        $fields_form = array();

        // API key
        $fields_form[]['form'] = array(
            'legend' => array(
                'title' => $this->l('API key'),
            ),
            'description' => $this->l('You must have a MailChimp account. You can create one on their website : ')
                .'<a href="http://eepurl.com/-dfjz" target="_blank">http://mailchimp.com/</a>',
            'input' => array(
                array(
                    'type'      => 'text',
                    'label'     => $this->l('Mailchimp API key'),
                    'desc'      => $this->l('Example: 123456789abcdef0123456789abcdef0-us2')
                        .' <a href="http://eepurl.com/im9k" target="_blank">http://eepurl.com/im9k</a>',
                    'name'      => 'MAILCHIMP_API_KEY',
                    'size'      => 45,
                    'required'  => true
                )
            ),
            'submit' => array(
                'title' => $this->l('Save'),
                'name'  => 'submitKey',
                'class' => 'button'
            )
        );

        // List
        $lists = $this->getLists();
        $fields_form[]['form'] = array(
            'legend' => array(
                'title' => $this->l('Default list'),
            ),
            'input' => array(
                array(
                    'type'      => 'select',
                    'label'     => $this->l('Mailchimp list'),
                    'desc'      => $this->l('How to create one:').' <a href="http://eepurl.com/gOHY" target="_blank">http://eepurl.com/gOHY</a>',
                    'name'      => 'MAILCHIMP_LIST_ID',
                    'options'   => array(
                        'default'   => array(
                            'label'     => $this->l('Select a list'),
                            'value'     => 0
                        ),
                        'query'     => $lists,
                        'id'        => 'id',
                        'name'      => 'name',
                    ),
                    'required'  => true
                )
            ),
            'submit'    => array(
                'title'     => $this->l('Save'),
                'name'      => 'submitList',
                'class'     => 'button'
            )
        );

        // Settings
        $fields_form[]['form'] = array(
            'legend'    => array(
                'title'     => $this->l('Settings'),
            ),
            'input'     => array(
                array(
                    'type'      => (version_compare(_PS_VERSION_, '1.6') < 0) ? 'radio' : 'switch',
                    'label'     => $this->l('Double Opt in', get_class($this), null, false),
                    'name'      => 'MAILCHIMP_DOUBLE_OPTIN',
                    'required'  => false,
                    'class'     => 't',
                    'is_bool'   => true,
                    'values'    => array(
                        array(
                            'id'    => 'double_option_on',
                            'value' => 1,
                            'label' => $this->l('Enabled', get_class($this), null, false)
                        ),
                        array(
                            'id'    => 'double_option_off',
                            'value' => 0,
                            'label' => $this->l('Disabled', get_class($this), null, false)
                        )
                    ),
                ),
                array(
                    'type'      => (version_compare(_PS_VERSION_, '1.6') < 0) ? 'radio' : 'switch',
                    'label'     => $this->l('Delete member on unsubscribe', get_class($this), null, false),
                    'name'      => 'MAILCHIMP_DELETE_MEMBER',
                    'required'  => false,
                    'class'     => 't',
                    'is_bool'   => true,
                    'values'    => array(
                        array(
                            'id'    => 'delete_member_on',
                            'value' => 1,
                            'label' => $this->l('Enabled', get_class($this), null, false)
                        ),
                        array(
                            'id'    => 'delete_member_off',
                            'value' => 0,
                            'label' => $this->l('Disabled', get_class($this), null, false)
                        )
                    ),
                ),
            ),
            'submit'    => array(
                'title'     => $this->l('Save'),
                'name'      => 'submitSettings',
                'class'     => 'button'
            )
        );

        $helper = new HelperForm();

        // Module, token and currentIndex
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

        // Language
        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;

        // Title and toolbar
        $helper->title = $this->displayName;
        $helper->show_toolbar = true;
        $helper->toolbar_scroll = true;
        $helper->submit_action = 'submit'.$this->name;
        $helper->toolbar_btn = array();

        // Load current value
        $helper->fields_value['MAILCHIMP_API_KEY'] = Configuration::get('MAILCHIMP_API_KEY');
        $helper->fields_value['MAILCHIMP_LIST_ID'] = Configuration::get('MAILCHIMP_LIST_ID');

        $helper->fields_value['MAILCHIMP_DOUBLE_OPTIN'] = Configuration::get('MAILCHIMP_DOUBLE_OPTIN');
        $helper->fields_value['MAILCHIMP_DELETE_MEMBER'] = Configuration::get('MAILCHIMP_DELETE_MEMBER');

        return $helper->generateForm($fields_form);
    }

    private function prepareHook()
    {
        if (Tools::isSubmit('submitNewsletter')) {
            $email = Tools::getValue('email');
            if (empty($email) || !Validate::isEmail($email)) {
                return $this->l('Invalid email address');
            }

            /* Unsubscription */
            if (Tools::getValue('action') == '1') {
                return $this->unregister($email);
            }

            /* Subscription */
            if (Tools::getValue('action') == '0') {
                return $this->register($email, array('optin_ip' => Tools::getRemoteAddr()));
            }
        }

        return true;
    }

    private function register($email, $data)
    {
        $list_id = Configuration::get('MAILCHIMP_LIST_ID');
        if (!$this->isConfigured() || $list_id === '0') {
            return false;
        }

        $mailchimp = $this->getClient();

        $merge_vars = $data;

        // add language
        if (!array_key_exists('mc_language', $merge_vars)) {
            $merge_vars['mc_language'] = $this->context->language->iso_code;
        }

        $double_optin = Configuration::get('MAILCHIMP_DOUBLE_OPTIN');

        try {
            $mailchimp->subContact($list_id, $email, $merge_vars, $double_optin, true);
            return true;
        } catch (Exception $exception) {
            return false;
        }
    }

    private function unregister($email)
    {
        $list_id = Configuration::get('MAILCHIMP_LIST_ID');
        if (!$this->isConfigured() || $list_id === '0') {
            return false;
        }

        $mailchimp = $this->getClient();

        $delete_member = Configuration::get('MAILCHIMP_DELETE_MEMBER');

        try {
            $mailchimp->unsubContact($list_id, $email, $delete_member);
            return true;
        } catch (Exception $exception) {
            return false;
        }
    }

    public function hookActionObjectCustomerAddAfter($params)
    {
        $new_customer = $params['object'];
        if (!Validate::isLoadedObject($new_customer)) {
            return false;
        }

        $newsletter = $new_customer->newsletter;
        $email = $new_customer->email;
        if (!$newsletter || !Validate::isEmail($email)) {
            return true;
        }

        $merge_vars = array(
            'FNAME'         => $new_customer->firstname,
            'LNAME'         => $new_customer->lastname,
            'optin_ip'      => $new_customer->ip_registration_newsletter,
            'optin_time'    => $new_customer->newsletter_date_add,
        );

        return $this->register($email, $merge_vars);
    }

    public function hookActionObjectCustomerUpdateAfter($params)
    {
        $customer   = $params['object'];
        if (!Validate::isLoadedObject($customer)) {
            return false;
        }
        if (!isset($customer->newsletter)) {
            return false;
        }

        if ($customer->newsletter == 0) {
            return $this->unregister($customer->email);
        } else {
            $merge_vars = array(
                'FNAME'         => $customer->firstname,
                'LNAME'         => $customer->lastname,
                'optin_ip'      => $customer->ip_registration_newsletter,
                'optin_time'    => $customer->newsletter_date_add,
            );
            return $this->register($customer->email, $merge_vars);
        }
    }

    public function hookDisplayHeader($params)
    {
        $this->prepareHook();
    }

    public function hookDisplayLeftColumn($params)
    {
        $this->hookDisplayHeader($params);
    }

    public function hookDisplayRightColumn($params)
    {
        $this->hookDisplayHeader($params);
    }

    public function hookDisplayFooter($params)
    {
        $this->hookDisplayHeader($params);
    }

    public function confirmEvent()
    {
        $token = Configuration::get('MAILCHIMP_WEBHOOK_TOKEN');
        if ($token === false) {
            return false;
        }

        if (!Tools::getIsset('token') || Tools::getValue('token') != $token) {
            return false;
        }

        if (!Tools::getIsset('type')) {
            return false;
        }

        $data = Tools::getValue('data');
        switch (Tools::getValue('type')) {
            case 'unsubscribe':
                if (!array_key_exists('email', $data)) {
                    return false;
                }
                $c = new Customer();
                if ($c->getByEmail($data['email'])) {
                    $c->newsletter    = 0;
                    $c->ip_registration_newsletter = null;
                    $c->newsletter_date_add = null;
                    $c->update();
                }
                break;
            case 'subscribe':
                if (!array_key_exists('email', $data) || !array_key_exists('ip_opt', $data)) {
                    return false;
                }
                $c = new Customer();
                if ($c->getByEmail($data['email'])) {
                    $c->newsletter    = 1;
                    $c->ip_registration_newsletter = $data['ip_opt'];
                    $c->newsletter_date_add = Tools::getValue('fired_at');
                    $c->update();
                }
                break;
        }
        return true;
    }
}
