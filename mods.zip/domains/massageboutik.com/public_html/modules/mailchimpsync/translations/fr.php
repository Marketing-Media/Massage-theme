<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_b67f8f1a5223ce3f8fe9699f49ee5ac0'] = 'Mailchimp Sync';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_81431b66e94ab0f0b4775cf6341488b6'] = 'Synchronise automatiquement votre liste d\'abonnés dans PrestaShop avec votre compte MailChimp, et inversement aussi.';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_78d2d84f5fbafa1260f72c39fa0baa2c'] = 'Etes-vous sûr de vouloir désinstaller ce module ? Tous vos réglages seront perdus.';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_9540dc2a82bc4e981db41557b57bb082'] = 'Vous n\'avez pas encore renseigné votre liste d\'abonnés MailChimp.';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_0c388aab925fc0c95e0ad5580d989f52'] = 'Vous n\'avez pas encore renseigné votre clé API MailChimp.';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_88dca3cc785d5f8f4569e346a842c029'] = 'Clé API invalide';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_c888438d14855d7d96a2724ee9c306bd'] = 'Réglages sauvegardés';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_8d8c5af36af7d1c06fa0658a251620b6'] = 'Liste invalide';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_7b0b542a837a451a546d78bf48608d25'] = 'Paramètres invalides';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_656a6828d7ef1bb791e42087c4b5ee6e'] = 'Clé API';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_e959b1e718c8ec4664ff723347420ddb'] = 'Vous devez avoir un compte MailChimp. Vous pouvez en créer un gratuitement sur leur site internet : ';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_fdebfefcc5e364b9d0f7e5e7fd737a36'] = 'Clé API MailChimp';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_49c5dd55b74f571f422c34064ff9506e'] = 'Exemple : 123456789abcdef0123456789abcdef0-us2';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_c0aea4fd10fe659b3e1691eedf343492'] = 'Liste';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_f8b381451aec9efa624f9f23c516d182'] = 'Liste MailChimp';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_27ca16752194caef767ce8f84636694c'] = 'Comment en créer une : ';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_1a7c1abde79b64cdc74a51fa07414842'] = 'Choisissez une liste';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_85fb5edbed9c4f5b01e208289dad3f31'] = 'Double opt in';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_2b7747f30d02ff4d7aee1192aa661928'] = 'Supprimer le contact au désabonnement';
$_MODULE['<{mailchimpsync}prestashop>mailchimpsync_59e4904d4366fab35a8282f418e699de'] = 'Adresse email invalide';
