<?php
/**
 * 2007-2015 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2015 PrestaShop SA
 *  @license   http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

require _PS_MODULE_DIR_.'mailchimpsync/vendor/autoload.php';

class MailChimpClient
{
    private $api_root = 'https://api.mailchimp.com/3.0';
    private $api_key = '';
    private $headers = array();
    private $options = array();

    /**
     * @param string $api_key
     */
    public function __construct($api_key)
    {
        $this->api_key = $api_key;

        $dc = 'us1';
        if (strstr($this->api_key, '-')) {
            list($key, $dc) = explode('-', $this->api_key, 2);
            if (!$dc) {
                $dc = 'us1';
            }
        }
        $this->api_root = str_replace('https://api', 'https://'.$dc.'.api', $this->api_root);
        $this->headers  = array(
            'User-Agent'    => 'MailChimp-PHP/3.0',
            'Content-Type'  => 'application/json'
        );
        $this->options  = array(
            'auth'          => array('apikey', $api_key)
        );
    }

    /**
     * @return bool
     * @throws Requests_Exception
     */
    public function ping()
    {
        $url = $this->api_root.'/';
        $response = Requests::get($url, $this->headers, $this->options);
        $response->throw_for_status();
        return $response->success;
    }

    /**
     * get all lists
     * @return array
     * @throws Requests_Exception
     */
    public function getLists()
    {
        $url = $this->api_root.'/lists/';
        $response = Requests::get($url, $this->headers, $this->options);

        $response->throw_for_status();
        $result = Tools::jsonDecode($response->body, true);
        return $result;
    }

    /**
     * add webhook
     * @param string $list_id
     * @param string $webhook_url
     * @param array $actions
     * @return bool
     * @throws Exception
     */
    public function webhookAdd($list_id, $webhook_url, array $actions)
    {
        $params = array(
            'id'        => $list_id,
            'url'       => $webhook_url,
            'actions'   => $actions
        );
        return $this->call('/lists/webhook-add', $params);
    }

    /**
     * delete webhook
     * @param string $list_id
     * @param string $webhook_url
     * @return bool
     * @throws Exception
     */
    public function webhookDel($list_id, $webhook_url)
    {
        $params = array(
            'id'    => $list_id,
            'url'   => $webhook_url
        );
        return $this->call('/lists/webhook-del', $params);
    }

    private function call($url, $params)
    {
        $api_root = str_replace('3.0', '2.0', $this->api_root);
        $url = $api_root.$url.'.json';
        $params['apikey'] = $this->api_key;
        $response = Requests::post($url, $this->headers, Tools::jsonEncode($params));
        $response->throw_for_status();
        return $response->success;
    }

    /**
     * get details of list
     * @param string $list_id
     * @return array
     * @throws Requests_Exception
     */
    public function getList($list_id)
    {
        $url = $this->api_root.'/lists/'.$list_id;
        $response = Requests::get($url, $this->headers, $this->options);

        $response->throw_for_status();
        $result = Tools::jsonDecode($response->body, true);
        return $result;
    }

    /**
     * ckeck subscriber's status
     * @param string $list_id
     * @param string $email
     * @return string {subscribed|unsubscribed|pending|cleaned}
     * @throws Requests_Exception
     */
    public function checkStatus($list_id, $email)
    {
        $url = $this->api_root.'/lists/'.$list_id.'/members/'.$this->hash($email);
        $response = Requests::get($url, $this->headers, $this->options);

        $response->throw_for_status();

        $result = Tools::jsonDecode($response->body, true);
        return $result['status'];
    }

    /**
     * add contact to list
     * @param string $list_id
     * @param string $email
     * @param array $merge_vars
     * @param bool $double_optin
     * @param bool $force
     * @return bool
     * @throws Requests_Exception
     */
    public function subContact($list_id, $email, $merge_vars, $double_optin, $force = false)
    {
        $data = array(
            'email_address' => $email,
            'status'        => $double_optin ? 'pending' : 'subscribed',
            'merge_fields'  => $merge_vars,
        );

        if (array_key_exists('mc_language', $merge_vars)) {
            $data['language'] = $merge_vars['mc_language'];
        }

        if (array_key_exists('optin_ip', $merge_vars)) {
            $data['ip_signup'] = $merge_vars['optin_ip'];
        }

        if (array_key_exists('optin_time', $merge_vars)) {
            $data['timestamp_signup'] = $merge_vars['optin_time'];
        }

        try {
            $url = $this->api_root.'/lists/'.$list_id.'/members';
            $response = Requests::post($url, $this->headers, Tools::jsonEncode($data), $this->options);
            $response->throw_for_status();
        } catch (Exception $exception) {
            // contact is already member of list, force subscription ?
            if ($exception->getCode() == 400 && $force) {
                $url = $this->api_root.'/lists/'.$list_id.'/members/'.$this->hash($email);
                $response = Requests::patch($url, $this->headers, Tools::jsonEncode($data), $this->options);
                $response->throw_for_status();
            }
        }

        return true;
    }

    /**
     * remove contact from list
     * @param string $list_id
     * @param string $email
     * @param bool $delete_member
     * @return bool
     * @throws Requests_Exception
     */
    public function unsubContact($list_id, $email, $delete_member)
    {
        $url = $this->api_root.'/lists/'.$list_id.'/members/'.$this->hash($email);

        if ($delete_member) {
            $response = Requests::delete($url, $this->headers, $this->options);
        } else {
            $data = array(
                'status'    => 'unsubscribed'
            );
            $response = Requests::patch($url, $this->headers, Tools::jsonEncode($data), $this->options);
        }

        $response->throw_for_status();
        return $response->success;
    }

    /**
     * create hash from email
     * @param $email
     * @return string
     */
    private function hash($email)
    {
        return md5(Tools::strtolower($email));
    }
}
