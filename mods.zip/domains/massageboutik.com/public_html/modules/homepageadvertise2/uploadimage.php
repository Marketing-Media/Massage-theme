<?php
print_r('User is not logged in');
?>