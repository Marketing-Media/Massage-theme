<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_488c7a3a949fe21ee5c64a7daeaf81f7'] = 'Anuncios en Homepage';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_4ea097c97fdfc958cd02f4551094d347'] = 'Muestra imágenes de anuncios en la homepage';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_c888438d14855d7d96a2724ee9c306bd'] = 'Parámetros actualizados';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_f4f70727dc34561dfde1a3c529b6205c'] = 'Parámetros';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_fff0d600f8a0b5e19e88bfb821dd1157'] = 'Imágenes';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'Posición';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_be53a0541a6d36f6ecb879fa2c584b08'] = 'Imágen';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Enlace';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_4994a8ffeba4ac3140beb89e8d41f174'] = 'Idioma';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_386c339d37e737a436499d423a77df0c'] = 'Moneda';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Habilitado';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_f2a6c498fb90ee345d997f888fce3b18'] = 'Eliminar';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_f19e7cb43f25ebe5fd0fe1e145f2f558'] = 'No hay imagen en el directorio del módulo';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_06c0d8d1c0ccbe8c703144fab175e705'] = 'Añadir una imagen';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_06933067aafd48425d67bcb01bba5cb6'] = 'Actualizar';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_258f49887ef8d14ac268c92b02503aaa'] = 'Arriba';
$_MODULE['<{homepageadvertise}prestashop>homepageadvertise_08a38277b0309070706f6652eeae9a53'] = 'Abajo';
