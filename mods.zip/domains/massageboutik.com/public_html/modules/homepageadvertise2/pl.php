<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_9a3b3dc422c2cc5c148b437a485b7157'] = 'Pokaz slajdów na stronie głownej';
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_7396c62edce8704d17b94383bc4fb990'] = 'Tutaj konfigurujemy slider na stronie głownej';
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_c888438d14855d7d96a2724ee9c306bd'] = 'Ustawienia zaaktualizowane';
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_fff0d600f8a0b5e19e88bfb821dd1157'] = 'Obrazki';
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'Pozycje';
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_be53a0541a6d36f6ecb879fa2c584b08'] = 'Obrazek';
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Link';
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_4994a8ffeba4ac3140beb89e8d41f174'] = 'Język';
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Właczony';
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_f2a6c498fb90ee345d997f888fce3b18'] = 'Usuń';
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_f19e7cb43f25ebe5fd0fe1e145f2f558'] = 'Brak zdjęcia';
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_06c0d8d1c0ccbe8c703144fab175e705'] = 'Dodaj obrazek';
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_06933067aafd48425d67bcb01bba5cb6'] = 'Aktualizuj';
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_258f49887ef8d14ac268c92b02503aaa'] = 'Góra';
$_MODULE['<{simpleslideshow}prestashop>simpleslideshow_08a38277b0309070706f6652eeae9a53'] = 'Dół';
