<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{graphvisifire}prestashop>graphvisifire_46495d329b07c973daa82a7a9c084d6b'] = 'Visifire';
$_MODULE['<{graphvisifire}prestashop>graphvisifire_8fb4e2a61c48721ee73f9b9189fd19e1'] = 'Visifire est un pack de composants open-source permettant de visualiser graphiquement des données. Il utilise la technologie Microsoft Silverlight 2 beta 2.';
